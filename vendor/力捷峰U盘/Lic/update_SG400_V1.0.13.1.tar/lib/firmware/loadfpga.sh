#!/bin/bash

echo 0 > /sys/class/fpga_manager/fpga0/flags

echo project_S2G_wrapper.bit.bin > /sys/class/fpga_manager/fpga0/firmware

