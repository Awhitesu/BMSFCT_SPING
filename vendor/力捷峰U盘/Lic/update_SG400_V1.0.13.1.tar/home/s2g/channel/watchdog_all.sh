#!/bin/bash

count=1
while [ $count -le 5 ]
do
    cd /home/s2g/channel/
    /home/s2g/channel/CHProcess &
    pid=$!
    echo "channel pid: $pid"
    
    while (( 1 ))
    do
    # check whether process is still running
    #R (running)", "S (sleeping)", "D (disk sleep)", "T (stopped)", "t(tracing stop)", "Z (zombie)", or "X (dead)"        
        if [ -f /proc/$pid/status ]
        then
            state=$(grep "State:" /proc/$pid/status)
            # echo "state1: $state"
            state="${state:7:2}"
            # echo "state2: $state"
            if [ "$state" == "T" ] || [ "$state" == "Z" ] || [ "$state" == "X" ]
            then
                echo "kill channel 1"
                kill -9 $pid #when process is halt
                break
            else            
                # echo "sleep"
                sleep 5s 
            fi
        else
            echo "$pid is not exist"
            break
        fi  
    done
    ((count++))   
    # echo "count: $count"
done
echo "channel reboot"
#reboot
