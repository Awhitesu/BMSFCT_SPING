#!/bin/sh

new_username="opteeq"
new_password="OptEeQ+1053"

if id "$new_username" >/dev/null 2>&1; then
    echo "[error]: User exists"
else
    useradd -M "$new_username"

    if [ $? -eq 0 ]; then
        echo "$new_username:$new_password" | chpasswd

        echo "New user '$new_username' has been created with the password '$new_password'."

        rm -rf /home/opteeq

        chown -R "$new_username" /run/media/mmcblk0p1/proj
        chown -R "$new_username" /run/media/mmcblk0p1/log
    else
        echo "[error]: add new user fail"
    fi
fi

