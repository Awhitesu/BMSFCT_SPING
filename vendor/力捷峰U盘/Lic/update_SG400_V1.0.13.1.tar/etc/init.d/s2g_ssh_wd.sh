#/bin/sh

hits=$(grep "Invalid\|Failed password" /var/log/dmesg | wc -l)
echo "hits: $hits"
# If they hit us more than 3 times
if [ $hits -ge 3 ];
then
    msg="Detected brute force attack on SSH"

    # Stop SSH and print on log (only if it hasn't be already stopped)
    attack=$(grep "$msg" /var/log/dmesg | wc -l)
    if [ $attack -lt 1 ]
    then
        echo $msg >> /var/log/dmsg
        /etc/init.d/sshd stop
        echo "stop ssh"
        echo $msg >> /home/s2g/log/all.log
    fi
fi
