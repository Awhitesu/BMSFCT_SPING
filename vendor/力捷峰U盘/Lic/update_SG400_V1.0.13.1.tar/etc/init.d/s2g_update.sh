#!/bin/sh

get_type() {
    tar_file=$1
    file_path="home/s2g/config.xml"
    
    temp_dir=$(mktemp -d)
    tar -xf $tar_file -C $temp_dir $file_path

    type_value=$(sed -n '/<type>/,/<\/type>/p' $temp_dir/$file_path | sed '1d;$d')

    # echo "new type: $type_value"
    rm -rf $temp_dir

    echo $type_value
}

get_cur_type() {
    file_path="home/s2g/config.xml"

    type_value=$(sed -n '/<type>/,/<\/type>/p' /$file_path | sed '1d;$d')
   
    # echo "cur type: $type_value"    

    echo $type_value
}

update=$(ls /run/update/update*.tar 2>/dev/null | head -n 1)
# echo "update file $update"
md5sum=$1
echo "md5sum $md5sum"
if [ ! -z "$update" ]; then
    cal_md5sum=$(md5sum $update | cut -f 1 -d " ")
    echo "cal md5 $cal_md5sum"
    if [[ "$md5sum" == "$cal_md5sum" ]]; then
        # md5 check pass
        echo "start update $update"
        
        new_type=$(get_type $update)
         
        cur_type=$(get_cur_type)
        
        # echo $new_type
        # echo $cur_type

        if [[ "$cur_type" == "$new_type" ]]; then
            tar -xf $update -C / 2>/run/update/error && sync
            # echo "check pass"
        else
            echo "device type error" > /run/update/error
        fi        
    else
        touch /run/update/error
        echo "md5 fail" > /run/update/error        
    fi
else
    echo "if false"    
fi
